package registrationScheduler.util;

public class Constants {
    public static final int NUM_COURSES         = 7;
    public static final int COURSE_CAPACITY     = 60;
    public static final int NUM_STUDENTS        = 80;
    public static final int COURSES_PER_STUDENT = 5;
}

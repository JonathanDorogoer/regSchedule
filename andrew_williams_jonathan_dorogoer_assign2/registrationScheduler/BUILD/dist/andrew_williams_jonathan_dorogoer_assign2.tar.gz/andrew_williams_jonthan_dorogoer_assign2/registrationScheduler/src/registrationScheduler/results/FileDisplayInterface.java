package registrationScheduler.results;


public interface FileDisplayInterface {
    public void writeSchedulesToFile(String outputFileName);
}

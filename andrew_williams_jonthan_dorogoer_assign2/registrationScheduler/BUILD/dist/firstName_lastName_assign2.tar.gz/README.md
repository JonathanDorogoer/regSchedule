# regSchedule
# All the ant commands he gave us is in the readme a few directories down.

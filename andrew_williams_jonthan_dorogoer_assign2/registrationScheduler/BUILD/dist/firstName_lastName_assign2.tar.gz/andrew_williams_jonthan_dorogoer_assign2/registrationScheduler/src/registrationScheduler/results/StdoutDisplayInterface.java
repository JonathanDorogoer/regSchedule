package registrationScheduler.results;

public interface StdoutDisplayInterface {
    public void writeSchedulesToScreen();
}
